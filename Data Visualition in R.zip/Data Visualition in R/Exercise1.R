x <- c(1:100)

plot(x,x^2)

plot(x,x^3)

plot(x,101-x)

plot(x,500/x)
